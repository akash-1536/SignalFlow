import { cp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { join } from "node:path";

const root = fileURLToPath(new URL(".", import.meta.url));
const dist = join(root, "dist");
const client = join(dist, "client");
const server = join(dist, "server");

await rm(dist, { recursive: true, force: true });
await mkdir(client, { recursive: true });
await mkdir(server, { recursive: true });

for (const file of ["index.html", "dashboard.html", "landing.css", "landing-sections.css", "services-sections.css", "design-system.css", "styles.css", "dashboard-redesign.css", "app.js", "landing.js", "og.png"]) {
  await cp(join(root, file), join(client, file));
}

await writeFile(join(client, "_headers"), "/*\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n  X-Frame-Options: SAMEORIGIN\n");
await writeFile(join(server, "index.js"), `export default {\n  async fetch(request, env) {\n    const url = new URL(request.url);\n    if (url.pathname === \"/\") url.pathname = \"/index.html\";\n    return env.ASSETS.fetch(new Request(url, request));\n  }\n};\n`);
await writeFile(join(server, "wrangler.json"), JSON.stringify({
  name: "signalflow-gtm-workflow",
  compatibility_date: "2026-08-24",
  main: "index.js",
  no_bundle: true,
  assets: { directory: "../client" },
  observability: { enabled: true },
  rules: [{ type: "ESModule", globs: ["**/*.js", "**/*.mjs"] }]
}));

const hosting = JSON.parse(await readFile(join(root, ".openai", "hosting.json"), "utf8"));
await mkdir(join(dist, ".openai"), { recursive: true });
await writeFile(join(dist, ".openai", "hosting.json"), JSON.stringify(hosting, null, 2));
