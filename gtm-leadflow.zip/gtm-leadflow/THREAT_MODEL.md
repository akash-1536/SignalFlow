# SignalFlow threat model

## Assets

- Lead files and normalized contact data
- Session cookies and passwords
- Export files and audit history
- Workspace-scoped configuration

## Controls implemented

- Argon2id password hashing, server-side sessions, HTTP-only cookies, and CSRF validation.
- Workspace membership checks on every application data endpoint.
- Role checks for mutations, exports, imports, and reviews.
- Upload extension, size, encoding, and header validation.
- MinIO object storage rather than database blobs.
- Idempotency keys for imports and immutable audit events for sensitive changes.
- CSV export escaping against spreadsheet formula injection.
- Ollama prompts contain an explicit allowlist and exclude email addresses, raw files, suppression data, and unrestricted notes.

## Production follow-up

- Enable TLS and `Secure` cookie settings behind a trusted reverse proxy.
- Turn on the optional ClamAV upload-scanning profile before accepting untrusted internet uploads.
- Rotate MinIO, database, and session secrets.
- Configure backups, alerting, account recovery, and data-deletion approval flows.

