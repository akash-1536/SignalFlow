# Gmail OAuth setup

Use a dedicated Gmail test mailbox first. Do not paste credentials into chat and do not commit `.env`.

1. In Google Cloud Console, create or select a project.
2. Enable **Gmail API**.
3. Configure the OAuth consent screen. For an external app in testing, add the dedicated mailbox as a test user.
4. Create an **OAuth client ID** of type **Web application**.
5. Add this exact authorized redirect URI:

   ```text
   http://localhost:8080/api/v1/integrations/gmail/callback
   ```

6. Generate a local encryption key inside the rebuilt API image:

   ```sh
   podman-compose run --rm api python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
   ```

7. Put the values in the untracked `.env` file:

   ```text
   CREDENTIAL_ENCRYPTION_KEY=<generated-key>
   GMAIL_CLIENT_ID=<oauth-client-id>
   GMAIL_CLIENT_SECRET=<oauth-client-secret>
   GMAIL_REDIRECT_URI=http://localhost:8080/api/v1/integrations/gmail/callback
   ```

8. Rebuild and restart with `podman-compose up --build`.
9. Open **Integrations**, select **Connect Gmail**, complete consent, and return to SignalFlow.
10. Create a draft campaign, send its test email to the dedicated mailbox, then explicitly activate only after reviewing the audience and sequence.

SignalFlow requests identity, `gmail.send`, and `gmail.readonly`. Read-only Gmail access is used for History API reply synchronization. Refresh tokens are encrypted at rest; access tokens are refreshed in memory and are not persisted.

For a manual reply test, establish the initial sync baseline, send a campaign message, reply in the same thread from another test account, then select **Sync replies**. Confirm classification, stopped enrollment, cancelled future messages, analytics, and audit events.
