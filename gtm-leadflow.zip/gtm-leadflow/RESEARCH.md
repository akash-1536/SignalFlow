# SignalFlow market research notes

Research refreshed on August 24, 2026. These notes informed the service positioning and information architecture; they are not customer evidence.

## Observed buyer problems

- Small revenue teams describe juggling routing, scheduling, enrichment, and CRM updates across several tools. The desired outcome is an orchestration layer with less manual maintenance, not another isolated data source. Source: [r/gtmengineering: inbound lead handling and routing](https://www.reddit.com/r/gtmengineering/comments/1vubtft/best_way_to_automate_inbound_lead_handlingrouting/).
- Outbound stacks become brittle when list building, enrichment, sending, and CRM synchronization are owned by separate tools and reconciled manually. Source: [r/gtmengineering: outbound at scale](https://www.reddit.com/r/gtmengineering/comments/1vujfz6/whats_still_not_solved_in_outbound_at_scale/).
- Practitioners distinguish signal-based targeting from broad ICP lists. Relevant triggers include hiring, funding, leadership changes, and technology changes. Source: [r/gtmengineering: signal-to-pipeline systems](https://www.reddit.com/r/gtmengineering/comments/1sinhsx/real_gtm_isnt_a_channel_guide_its_a_signal_to/).

## Observed proof patterns

- GTM engineering positioning becomes easier to understand when providers show a specific workflow before and after the intervention. Source: [r/gtmengineering: positioning a GTM-first agency](https://www.reddit.com/r/gtmengineering/comments/1upk2oa/invented_our_own_definition_as_a_gtmfirst_agency/).
- Hiring discussions emphasize a working workflow that can be demonstrated, not case-study claims alone. Source: [r/gtmengineering: getting a GTM engineering job](https://www.reddit.com/r/gtmengineering/comments/1sfwo00/best_way_to_get_a_job/).
- Current service sites commonly explain the challenge, implementation, integration stack, and measured result. Sources: [GTM Engineering Services case studies](https://www.gtmengineeringservices.com/case-studies) and [The GTM Engineering Company case studies](https://www.gtm-engineering.io/case-studies).

## Decisions applied to SignalFlow

- Lead with a broken-handoff problem rather than a broad promise about growth.
- Organize services around workflows customers can recognize and scope.
- Show a before-and-after operating flow with system events and failure controls.
- Label the portfolio case as a reference implementation because no verified customer evidence was provided.
- Treat external platforms as modeled integration boundaries, not active partnerships.
- Make the dashboard inspectable so recruiters and prospective clients can test the artifact directly.
