# SignalFlow design system

## Brand character

SignalFlow uses an editorial visual language for service positioning and a compact operational language for product evidence. The palette is calm and technical: warm paper, deep forest, teal for active decisions, and lime for high-value actions.

## Typography

- **Newsreader:** display headlines and important narrative statements.
- **Instrument Sans:** body copy, navigation, buttons, and product interface text.
- **IBM Plex Mono:** system events, states, technical metadata, labels, and code.

The fluid type scale is defined with `clamp()` tokens from `--sf-step--1` through `--sf-step-4`.

## Core tokens

- Color tokens: `--sf-forest-*`, `--sf-paper*`, `--sf-teal`, `--sf-mint`, `--sf-lime`, `--sf-amber`.
- Spacing tokens: `--sf-space-1` through `--sf-space-8`.
- Layout: `--sf-container` at 1180px, with wide sections using calculated page gutters.
- Geometry: 4px controls, 8px modules, restrained shadows, and one-pixel structural rules.

## Module rules

- Cards are used only for bounded product artifacts or reference evidence.
- Services use rows, process uses a timeline, workflow uses a connected grid, and integrations use grouped boundaries to avoid repetitive card walls.
- Teal communicates activity and decisions. Lime is reserved for primary actions and verified active states. Amber marks recovery and failure paths.
- Diagrams expose inputs, processing, decision branches, persistence, failure recovery, and operating controls.

## Interaction and accessibility

- Links, buttons, and disclosures have visible keyboard focus states.
- Section reveals use `IntersectionObserver` and are disabled when reduced motion is requested.
- Layouts recompose at 960px and 680px. Dense product previews scale inside an overflow-safe frame on mobile.
- Semantic buttons, links, headings, sections, details, and live status regions are preserved.
