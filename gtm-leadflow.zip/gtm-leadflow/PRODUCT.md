# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Users

Small B2B sales teams operate SignalFlow to turn account and contact data into qualified, reviewable outbound opportunities. Engineering recruiters evaluate the project as evidence of production-minded backend and product work.

## Product Purpose

SignalFlow imports accounts and contacts, joins them by normalized domain, enriches and scores them, routes qualified leads, generates evidence-bound local AI guidance, and runs approved outbound campaigns through a connected Gmail mailbox.

## Positioning

The product keeps deterministic qualification, local Ollama outputs, delivery controls, job history, and audit evidence connected in one local-first workflow. It never invents contacts or sends a campaign until a user tests and activates it.

## Operating Context

Users work in an authenticated workspace with CSV/XLSX imports, a local Ollama service, PostgreSQL, Redis/Celery workers, and optionally a Gmail mailbox authorized by OAuth.

## Capabilities and Constraints

- Account-only imports remain valid and create account research work, not fabricated contacts.
- Contact imports match imported accounts through normalized domains.
- Ollama is mandatory for AI qualification and draft generation.
- A campaign requires a real recipient email, test delivery, and explicit campaign activation.
- The default stack is free and open source and runs with Podman Compose.
- Gmail tokens are stored encrypted and never written to browser storage, exports, or logs.

## Brand Commitments

SignalFlow is a calm, technical GTM operations product. The authenticated application uses an evidence-first operations-console style inspired by Apify's task and run management patterns, without copying its visual design.

## Evidence on Hand

The repository includes live import, enrichment, scoring, routing, audit, Ollama, and outreach-draft workflows. It contains no customer logos, testimonials, or verified performance claims; future work must not fabricate them.

## Product Principles

1. Explain every automated decision with evidence.
2. Keep AI local, structured, and bounded by supplied data.
3. Make long-running work observable and recoverable.
4. Require an accountable human action before outbound delivery begins.
5. Protect tenant data, credentials, and recipients by default.

## Accessibility & Inclusion

The web application targets WCAG AA contrast, keyboard-operable controls, visible focus states, responsive layouts, and clear loading, empty, success, and error states.
