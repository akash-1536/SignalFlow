# SignalFlow project handoff

Treat the directory containing this file as `<project-root>`. No command or configuration in this handoff depends on the original machine path.

## Product

SignalFlow is a local-first GTM operations platform and proof-of-work project for a backend-focused engineer. It demonstrates a real account/contact import pipeline, deterministic qualification, mandatory local AI, campaign safety gates, SMTP/IMAP or optional Gmail delivery, reply synchronization, durable background jobs, analytics, and tenant-aware auditability.

Its goal is to help a small B2B sales team turn imported accounts, contacts, shared company inboxes, and outreach replies into controlled opportunities with less manual work and clearer operational evidence. It also gives recruiters inspectable proof of API design, data modeling, RBAC, idempotency, deduplication, transactional outbox processing, workers, schema-validated AI, encrypted credentials, rate limits, failure recovery, and responsive product design.

No client names, customer outcomes, integrations, or metrics should be presented as real without verifiable evidence. The public case study and static dashboard use simulated data.

## Current product experience

The primary application navigation is intentionally simple:

1. **Home** — campaign-ready prospect count, active work, and active campaigns.
2. **Prospects** — reusable Accounts and Contacts library.
3. **Campaigns** — the primary workflow. Each campaign has **Audience**, **Sequence**, **Launch**, and **Results** tabs.
4. **Inbox** — synchronized replies and their next-action classification.
5. **Settings** — progressive disclosure for Ollama status, mailbox integrations, jobs, audit history, and suppression controls.

Campaign uploads use `auto` detection for accounts versus contacts. Account-only imports appear in the campaign Audience tab as **Missing email**: they are useful for enrichment and AI research but cannot be launched. Contact imports with a valid `Email` and matching `Company Domain` join to those accounts and become potential recipients. A company-name field is not an email field.

## Implemented workflow

```text
account/contact import
  -> normalized account domain and email identity
  -> deduplication and account/contact join
  -> deterministic enrichment, ICP scoring, and owner routing
  -> required local Ollama account/lead analysis
  -> campaign-level Ollama sequence generation from goal, offer, persona, CTA, and verified proof
  -> human sequence review, campaign draft, business hours, and send limits
  -> SMTP/IMAP (default) or optional Gmail connection, test email, manager approval, explicit activation
  -> scheduled threaded delivery
  -> Gmail History polling and reply/bounce/opt-out classification
  -> immediate sequence stop and suppression where required
  -> jobs, analytics, audit, and operational recovery
```

Only explicitly selected campaign recipients with completed Ollama analysis can enroll. An approved per-lead draft can supply extra personalization; the reviewed campaign sequence is the baseline delivery copy. Suppression is rechecked at delivery time. Gmail API acceptance is not described as proven delivery, and open tracking is not implemented.

## Architecture

- Frontend: React, TypeScript, Vite, TanStack Query.
- API: FastAPI, SQLAlchemy, versioned `/api/v1` routes, session auth, CSRF, workspace RBAC, Redis rate limiting.
- Persistence: PostgreSQL for domain/job/audit state; MinIO for imports and exports.
- Async: Celery + Redis, transactional outbox, Celery beat scheduler.
- AI: mandatory host-local Ollama with explicit Pydantic schemas and evidence-bound prompts.
- Email: SMTP/IMAP adapter (default) and optional Gmail OAuth 2.0 with PKCE, Fernet-encrypted refresh tokens, Gmail send API, and History API polling.
- Runtime: Podman Compose and Caddy. No paid runtime or provider is required.

Read [ARCHITECTURE.md](ARCHITECTURE.md), [DESIGN.md](DESIGN.md), [GMAIL_SETUP.md](GMAIL_SETUP.md), [RUNBOOK.md](RUNBOOK.md), and [THREAT_MODEL.md](THREAT_MODEL.md) before changing boundaries.

## Important paths

| Path | Purpose |
| --- | --- |
| `apps/api/app/main.py` | HTTP APIs, auth gates, campaign/Gmail/job endpoints |
| `apps/api/app/tasks.py` | imports, Ollama, outbox, scheduler, Gmail sync workers |
| `apps/api/app/models.py` | tenant, lead, campaign, mailbox, message, suppression, and job models |
| `apps/api/app/campaigns.py` | audience safety, business-hour scheduling, classification |
| `apps/api/app/smtp_imap.py` | local SMTP delivery and IMAP reply-sync adapter |
| `apps/api/app/gmail.py` | OAuth, encryption, Gmail API adapter, MIME parsing |
| `apps/web/src/main.tsx` | application shell and domain routes |
| `apps/web/src/features/` | campaigns, Gmail integrations, and jobs modules |
| `apps/web/src/components/ui.tsx` | reusable console primitives |
| `migrations/versions/` | forward database migrations |
| `tests/` | deterministic unit and contract tests |
| `.env.example` | safe local configuration placeholders |

## New-machine start

```sh
cd <project-root>
cp .env.example .env
ollama pull llama3.2:3b
ollama serve
podman machine init       # run only when no Podman machine exists
podman machine start
podman-compose up --build
```

Open `http://localhost:8080/app/`. Confirm **Settings → Required Ollama** reports ready. For email, set the SMTP/IMAP fields in `.env`, restart the stack, and connect the local mailbox in Settings. Gmail OAuth is optional; configure it only after reading `GMAIL_SETUP.md`. Keep credentials in the untracked `.env` file and use a dedicated test mailbox first.

## Operator smoke test

1. Create a campaign in **Campaigns**.
2. In **Audience**, upload `samples/contact-leads.csv`, or upload an accounts file followed by a contacts file containing `Email` and `Company Domain`.
3. Wait for the preparation strip to reach **Ready**. If Ollama is unavailable, it must show a clear blocked state rather than fabricate data.
4. In **Sequence**, complete the campaign brief and choose **Generate with local Ollama**. Review/edit the three steps and save.
5. In **Launch**, choose a connected test mailbox, retain conservative limits, approve, send a test email, then explicitly launch.
6. Reply from the test recipient. Synchronize the mailbox or wait for polling. Verify that the enrollment stops; unsubscribe and hard-bounce replies must also create suppression records.

## Known boundaries and continuation priorities

- Account-only exports cannot create sendable leads unless they contain an actual email column. Treat “Company Name for Emails” as a name unless its values validate as email addresses.
- The campaign audience is explicit. Do not restore the old behaviour that sent to every qualified lead in a workspace.
- Account-only rows are visible as `missing_email`; they remain researchable but must be excluded from activation.
- The simplified Prospects screen is intentionally compact. If restoring detailed AI evidence, add an accessible modal/drawer rather than raw JSON or a below-the-fold panel.
- Keep the API's `campaign_prepare` repair path idempotent: duplicate contact imports can resolve to the same normalized lead.

## Validation and current external dependency

```sh
python3 -m compileall -q apps/api/app
podman-compose run --rm -v ./tests:/app/tests:ro api pytest -q tests
podman-compose run --rm web npm run build
```

Real Gmail OAuth/delivery cannot be validated without user-owned Google OAuth credentials and consent. SMTP/IMAP delivery needs a user-owned test mailbox and app password where applicable. A real Ollama run requires the configured local model to be installed and reachable. These are setup inputs, not repository credentials.

## Safe continuation

Do not bypass the test/approval/activation sequence, AI eligibility gate, suppression checks, or ambiguous-send recovery behavior. Do not log tokens or full email bodies. Add new providers behind adapters and preserve provider IDs, tenant identity, idempotency, and audit evidence.
