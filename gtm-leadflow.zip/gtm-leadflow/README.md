# SignalFlow

SignalFlow is a local-first outbound GTM operations platform and backend portfolio project. It turns account or contact CSV/XLSX files into qualified, human-approved campaigns, sends through Gmail, synchronizes replies, stops unsafe follow-ups, and preserves an auditable record of every decision.

The public site is at `/`; the working React console is at `/app/`.

## Working flow

```text
Import accounts or contacts
  -> normalize domains and deduplicate
  -> join contacts to accounts
  -> deterministic enrichment, scoring, and routing
  -> mandatory schema-validated local Ollama analysis
  -> human review of per-lead three-step outreach
  -> campaign draft, Gmail test, approval, explicit activation
  -> business-hour scheduling with mailbox/domain limits
  -> Gmail delivery and History API reply sync
  -> stop on reply, unsubscribe, hard bounce, or suppression
  -> analytics, jobs, logs, and audit trail
```

Account exports containing company email fields are supported. Shared inboxes are marked as company inboxes; the system never invents a person or role. A later contact export joins by normalized company domain.

## Safety and evidence boundaries

- Ollama is mandatory for campaign-ready outreach; unavailable or malformed output becomes `blocked_ai_unavailable`.
- Only qualified, assigned, unsuppressed recipients with a completed Ollama output and an approved draft can be enrolled.
- Campaigns start as drafts. SMTP/IMAP or Gmail test delivery, manager approval, and explicit activation are separate gates.
- Gmail API acceptance is reported as sent, not proven delivery. Open tracking is not implemented.
- Imported/enriched facts used by AI copy are retained with model, prompt version, warnings, confidence, latency, and timestamps.
- No customer logos, results, testimonials, or production claims are fabricated.

## Free local stack

FastAPI, PostgreSQL, Redis, Celery, MinIO, React, TypeScript, Vite, Caddy, Ollama, and Podman are used. No paid provider is required. Gmail API usage is available without a paid email-delivery service, subject to Google account quotas and policies.

### Start

Install Podman, a Compose provider, and Ollama on the host. Then:

```sh
cd <project-root>
cp .env.example .env
ollama pull llama3.2:3b
ollama serve
podman machine init       # once, only if no Podman machine exists
podman machine start
podman-compose up --build
```

Open `http://localhost:8080/`, `http://localhost:8080/app/`, and `http://localhost:8080/docs`. The development login comes from `DEV_ADMIN_EMAIL` and `DEV_ADMIN_PASSWORD` in `.env`.

Gmail API is optional until delivery. To avoid Google Cloud OAuth, configure the free SMTP/IMAP adapter in `.env`, then open **Integrations** and select **Connect local mailbox**. SignalFlow verifies SMTP and IMAP access before adding the mailbox. For Gmail, use a dedicated test mailbox and an App Password. Never commit `.env` or paste credentials into chat. See [GMAIL_SETUP.md](GMAIL_SETUP.md) for the optional OAuth route.

## Operator demo

1. Import the account export in **Imports → Accounts** and start the job.
2. Import contacts in **Imports → Contacts**, or use company emails from an account export.
3. Track import, account-research, Ollama, campaign-enrollment, and Gmail-sync work in **Jobs**.
4. Review qualification in **Leads**, then approve generated sequences in **Outreach inbox**.
5. Connect a local SMTP/IMAP mailbox or Gmail OAuth in **Integrations**.
6. Create a campaign, select a mailbox, approve it, send a test, and activate it.
7. Reply from a test recipient and run **Sync replies**. Automatic polling also runs every `GMAIL_POLL_INTERVAL_SECONDS`.
8. Confirm the enrollment stopped, then inspect **Overview**, **Outreach inbox**, and **Audit log**.

## Validation

```sh
podman-compose run --rm -v ./tests:/app/tests:ro api pytest -q tests
podman-compose run --rm web npm run build
python3 -m compileall -q apps/api/app
```

Automated tests mock external behavior. Use a dedicated Gmail mailbox for the documented manual test. See [ARCHITECTURE.md](ARCHITECTURE.md), [RUNBOOK.md](RUNBOOK.md), [THREAT_MODEL.md](THREAT_MODEL.md), and [handoff.md](handoff.md).
