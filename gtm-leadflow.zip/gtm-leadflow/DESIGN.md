# SignalFlow application design

The authenticated application is a dense, calm operations console for GTM operators. It uses a neutral light surface, dark forest navigation, restrained teal actions, one module radius, compact tables, explicit statuses, and system UI typography for fast local loading.

Primary navigation follows operator objects: Overview, Accounts, Leads, Campaigns, Outreach inbox, Jobs, Imports, Integrations, Templates, Audit log, and Settings. Technical payloads are translated into statuses, evidence summaries, counters, logs, and timelines; raw data remains a developer detail rather than the default view.

Loading uses skeletons shaped like final content. Long-running work is represented by durable job phases and counters, never fake ETAs. Destructive and external actions use confirmation or staged gates. Keyboard focus is visible, contrast targets WCAG AA, motion is restrained, and responsive layouts recompose below 900px and 640px.

The public landing page retains its separate editorial design system. The application intentionally does not mimic Apify visually; it borrows the product grammar of runs, tasks, schedules, integrations, logs, and outputs.
