# SignalFlow architecture

## Event flow

```text
React console
    |
    v
FastAPI -- auth / CSRF / RBAC / rate limit / idempotency
    |                         |
    |                         +--> MinIO: original imports and exports
    v
PostgreSQL transaction
  domain rows + audit log + outbox event
    |
    v
Celery beat -> outbox dispatcher -> Redis queues
    |              |              |               |
 import worker   Ollama worker  campaign worker  Gmail sync
    |              |              |               |
    +--------------+--------------+---------------+
                           |
                           v
                PostgreSQL jobs, logs, messages,
                enrollments, suppressions, audit
                           |
                    SSE with polling fallback
```

## Domain boundaries

- Accounts retain every imported field in `profile_data`; normalized domain is the join key.
- Leads use normalized email as the tenant-scoped identity key. Existing data is filled, not silently overwritten.
- Deterministic enrichment, scoring, routing, suppression, business-hour scheduling, and send limits are authoritative.
- Ollama produces structured suggestions only from supplied evidence. Per-lead approved drafts provide the actual campaign copy.
- The transactional outbox separates committed state from at-least-once worker dispatch.
- `workflow_jobs` and `workflow_job_logs` expose progress, attempts, idempotency, cancellation, retry, phases, counters, and errors.
- A scheduled message is claimed as `sending` before the Gmail call. Ambiguous network outcomes require review instead of automatic duplicate delivery.
- Gmail thread IDs and API message IDs are persisted. History polling ignores sent mail, deduplicates inbound events, classifies replies, and stops future messages.
- Unsubscribe and hard-bounce classifications create durable suppression entries. Every send rechecks suppression.

## Campaign state gates

```text
draft -> approved -> test sent -> explicitly activated/running
                                     |       |
                                   pause   cancel
                                     |
                                   resume
```

Activation fails when no campaign-ready recipients exist. A campaign-ready recipient must be qualified, have an email, not be suppressed, and have a completed Ollama analysis with an approved outreach draft.

## Gmail security

- OAuth uses authorization code flow with PKCE and a ten-minute state record.
- Refresh tokens are encrypted with a server-side Fernet key; access tokens are short-lived and not stored.
- Scopes are limited to identity, Gmail send, and Gmail read-only access required for History synchronization.
- Mailbox actions are tenant-scoped and role-gated; logs omit tokens and message bodies by default.
- Scheduled History API polling is the free default. Pub/Sub is intentionally not required.

## Metric semantics

The console reports imported/qualified/campaign-ready leads, enrollments, Gmail API accepted sends, replies, interested replies, bounces, and unsubscribes. Gmail does not provide reliable final-delivery or open data through this implementation, so the UI labels that boundary explicitly.

## Scaling path

Partition workers by import, AI, delivery, and sync queues; use row-level locks with `SKIP LOCKED`; shard high-volume scheduled-message scans by workspace or send time; persist provider metadata without secrets; move rate-limit counters and scheduler leadership to dedicated Redis/Postgres infrastructure. Horizontal API workers remain stateless apart from encrypted server-side credentials.
