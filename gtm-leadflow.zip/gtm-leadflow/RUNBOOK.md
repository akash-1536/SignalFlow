# SignalFlow operational runbook

## First checks

```sh
podman-compose ps
podman-compose logs --tail=200 api worker outbox
curl http://localhost:8080/health/ready
ollama list
```

Open **Jobs** for the durable phase, counters, error, attempt, and latest structured log. Do not infer progress from a spinner.

## Import failed or stalled

Confirm PostgreSQL, Redis, MinIO, and the worker are healthy. A failed, cancelled, or partially completed job can be retried from **Jobs**; row identity and import idempotency prevent duplicate lead creation. Preserve row-level errors for review.

## `blocked_ai_unavailable`

Confirm `OLLAMA_MODEL` exactly matches `ollama list`, `ollama serve` is running on the host, and containers can reach `OLLAMA_BASE_URL`. Restart API and workers after `.env` changes. Retry the failed Ollama job. No campaign enrollment is allowed until structured AI output is validated and its draft is approved.

## Gmail needs reconnect

Verify the OAuth client is a Web application, the redirect URI exactly matches `.env`, and the test user is allowed by the consent screen. Reconnect from **Integrations**. Rotating `CREDENTIAL_ENCRYPTION_KEY` makes stored tokens unreadable and requires every mailbox to reconnect.

## Reply sync is empty

The first sync stores a Gmail History baseline. Send/reply after that baseline, then sync again. Confirm the reply stayed in the original Gmail thread. Automatic polling runs at `GMAIL_POLL_INTERVAL_SECONDS`.

## Message is not sending

Check, in order: campaign is running; mailbox is connected; recipient is not suppressed; approved Ollama draft exists; scheduled time is inside business hours; daily mailbox and per-domain limits are available. A message stuck in `sending` indicates an ambiguous provider outcome and must be reconciled in Gmail before retrying.

## Emergency stop

Pause or cancel the campaign in **Campaigns**. Add a recipient to **Settings → Suppression list** for an immediate durable stop. Disconnecting Gmail also prevents delivery but is broader than pausing one campaign.

## Validation after changes

Run API tests, the production frontend build, Alembic upgrade, and one manual dedicated-mailbox test. Never use a real prospect list for development validation.
